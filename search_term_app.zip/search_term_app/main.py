import pandas as pd
from IPython.display import display
import data_preprocessing

print("-------------------Search App-------------------\n")

ans = input("Do you want to reload the xlsx file? [y/n]")
if ans == 'y':
    data_preprocessing.producer()

df = pd.read_csv("result.csv")

# add percentage format
df['CTR'] = df['CTR'].apply(lambda x: '%.2f%%' % (x*100))
df['Average CPC'] = df['Average CPC'].apply(lambda x: '%.2f%%' % (x*100))
df['ACoS'] = df['ACoS'].apply(lambda x: '%.2f%%' % (x*100))
df['Conversion Rate within 1-week of a click'] = df['Conversion Rate within 1-week of a click'].apply(lambda x: '%.2f%%' % (x*100))

customer_search_term_lists = list(df['Customer Search Term'].unique())

def write_to_html(df):
    pd.set_option('colheader_justify', 'center')   # FOR TABLE <th>
    html_string = '''
    <html>
    <head><title>Search Result</title></head>
    <body>
        {table}
    </body>
    </html>.
    '''
    # OUTPUT AN HTML FILE
    with open('ResultPage.html', 'w') as f:
        f.write(html_string.format(table=df.to_html()))

term = input("\nEnter a search term: ")
while(1):
    if term not in customer_search_term_lists:
        print("\nThe term you enter is not in the search term lists! Enter again...\n")
        print("------------------------------------------------\n")
        term = input("Enter a search term: ")
    else:
        sdf = df[df['Customer Search Term'] == term]
        write_to_html(sdf)
        print("\nThe result is saved in ResultPage Html!\n")
        print("------------------------------------------------\n")
        term = input("Enter a search term: ")