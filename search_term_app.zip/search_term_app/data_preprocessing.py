import openpyxl
import pandas as pd
from openpyxl import Workbook
from IPython.display import display
import datetime
from nltk.stem import WordNetLemmatizer
# nltk.download('wordnet') ***

# data preprocessing

# helper function
# check if content of row has empty space
def check_row(row):
    # ACoS could be None
    for index, cell in enumerate(row):
        if cell.value == None and index not in [9,11,12,16]:
            return False
    return True

def max_r(sws):
    tol = 0
    maxr = sws.max_row
    maxc = 21
    # print(maxr)
    for index, row in enumerate(sws.iter_rows(min_row=1, min_col=1, max_row=maxr, max_col=maxc)):
        if not check_row(row):
            if tol >= 10:
                return index
            tol += 1
    return maxr
            
# get list of all data of all sheets
# sws: single work sheet
def add_one_sheet(sws, datalist):
    maxr = max_r(sws)
    maxc = 21
    # print(sws)
    # print("max_row:" + str(maxr))
    if maxr == 1:
        return
    for row in sws.iter_rows(min_row=2, min_col=1, max_row=maxr, max_col=maxc):
        if check_row(row):
            single_r = [cell.value for cell in row]
            datalist.append(single_r)

# add all sheets --> a datalist
def add_all_sheet(ws):
    datalist = []
    for index, sws in enumerate(ws):
        # print("index: " + str(index))
        add_one_sheet(sws, datalist)
        # print("datalist length: ")
        # print(len(datalist))
        # print('\n')
    return datalist

# if interval1 is contained in interval2, return 1
# if interval2 is contained in interval1, return -1
# else return 0
def time_interval_contain(interval1, interval2):
    start1 = interval1[0]
    start2 = interval2[0]
    end1   = interval1[1]
    end2   = interval2[1]
    if start1 >= start2 and end1 <= end2:
        return 1
    if start1 <= start1 and end1 >= end2:
        return -1
    return 0

def producer():
    print("Start loading data from xlsx.....")
    book = openpyxl.load_workbook("SearchTerm-10mm-RGBA-SlimPar.xlsx", data_only = True)
    print("Done\n")

    print("Start getting dataframe from sheets......")
    sheets = book.sheetnames
    # get all work sheets
    ws = []
    for i in range(len(sheets)):
        ws.append(book[sheets[i]])
    # get table columns
    maxc = ws[0].max_column
    column_names = {}
    for i in range(1, ws[0].max_column + 1):
        column_names[i-1] = ws[0].cell(row = 1, column = i).value
    datalist = add_all_sheet(ws)
    # create dataframe of datalist
    df = pd.DataFrame(datalist)
    df.rename(columns=column_names, inplace=True)
    # print(df)
    # display(df)
    print("Done\n")
    print("df size: ")
    print(df.shape)

    print("\nStart eliminating all plural words......")

    wnl = WordNetLemmatizer()
    customer_search_term_expression = df["Customer Search Term"]
    # get all search term list
    search_term_list = []
    for i in range(len(customer_search_term_expression)):
        terms = customer_search_term_expression[i].split(" ")
        for term in terms:
            if term not in search_term_list:
                search_term_list.append(term.strip())
    # print(search_term_list)
    # make a convert dict (from plural to singular)
    term_convert_dict = {}
    for term in search_term_list:
        term_convert_dict[term] = wnl.lemmatize(term)
    # some manual change
    term_convert_dict['uplights'] = 'uplight'
    # function to convert words in one string to singular format
    def singular_string(s):
        term_list = s.split(" ")
        term_list = [term_convert_dict[term.strip()] for term in term_list]
        new_str = ' '.join(term_list)
        return new_str
    # apply this to df
    df["Customer Search Term"] = df["Customer Search Term"].map(lambda x: singular_string(x))
    print("Done\n")

    print("Start eliminating unwanted time interval......")
    # initial a new dataframe df_no_contain_time
    df_no_contain_time = pd.DataFrame(columns = column_names)
    df_no_contain_time.rename(columns=column_names, inplace=True)
    # print(df_no_contain_time)
    # time interval process function
    def erase_dump_time_df(df):
        tmp_df = pd.DataFrame(columns = column_names)
        tmp_df.rename(columns=column_names, inplace=True)
        check_dict = []
        for index, row in df.iterrows():
            tmp_interval = (row['First Day of Impression'], row['Last Day of Impression'])
            # print(len(check_dict))
            if len(check_dict) == 0:
                check_dict.append(tmp_interval)
                #print(len(check))
            else:
                flag = 1
                for i in range(len(check_dict)):
                    if time_interval_contain(check_dict[i], tmp_interval) == 0:
                        # no contain relationship
                        pass
                    elif time_interval_contain(check_dict[i], tmp_interval) == 1:
                        # elem contained in tmp_interval
                        flag = 0
                        check_dict[i] = tmp_interval
                    elif time_interval_contain(check_dict[i], tmp_interval) == -1:
                        # tmp_interval contained in elem
                        flag = 0
                        break
                if(flag):
                    check_dict.append(tmp_interval)
        # remove dumplicate interval
        check_dict = list(set(check_dict))
        # print(check_dict)
        # add rows in tmp_df according to intervals in check_dict
        for elem in check_dict:
            tmp_df = tmp_df.append(df[(df["First Day of Impression"] == elem[0].strftime('%Y-%m-%d')) & (df["Last Day of Impression"] == elem[1].strftime('%Y-%m-%d'))])
        return tmp_df
    # main process (about five minutes)
    unique_terms = list(df['Customer Search Term'].unique())
    for term in unique_terms:
        tdf = df[df['Customer Search Term'] == term]
        tdf_t = erase_dump_time_df(tdf)
        df_no_contain_time = df_no_contain_time.append(tdf_t, ignore_index = True)
    print("Done\n")
    print("df_no_contain_time size: ")
    print(df_no_contain_time.shape)

    print("\nStart merge row process......(3 minutes) ")

    # small merge (for df of single custom search)
    def key_match_pair(sdf):
        sdf_s =  sdf[['Keyword','Match Type']]
        km = []
        for index, row in sdf_s.iterrows():
            kmcell = (row['Keyword'], row['Match Type'])
            if kmcell not in km:
                km.append(kmcell)
        return km

    # return a dict
    def merge_to_single_row(sdf, kmp, term_name):
        infod = {
        'Customer Search Term': term_name,
        'Keyword': kmp[0],
        'Match Type': kmp[1],
        'Impressions': 0,
        'Clicks': 0,
        'CTR': 0.0,
        'Total Spend': 0.0,
        'Average CPC': 0.0,
        'ACoS': 0.0,
        'Currency': 'USD',
        'Orders placed within 1-week of a click': 0,
        'Product Sales within 1-week of a click': 0.0,
        'Conversion Rate within 1-week of a click': 0.0,
        'Same SKU units Ordered within 1-week of click': 0,
        'Other SKU units Ordered within 1-week of click': 0,
        'Same SKU units Product Sales within 1-week of click': 0.0,
        'Other SKU units Product Sales within 1-week of click': 0.0
        }
        
        for index, row in sdf[(sdf['Keyword'] == kmp[0]) & (sdf['Match Type'] == kmp[1])].iterrows():
            infod['Impressions'] += int(row['Impressions'])
            infod['Clicks'] += int(row['Clicks'])
            infod['Total Spend'] += float(row['Total Spend'])
            infod['Orders placed within 1-week of a click'] += int(row['Orders placed within 1-week of a click'])
            infod['Product Sales within 1-week of a click'] += float(row['Product Sales within 1-week of a click'])
            infod['Same SKU units Ordered within 1-week of click'] += int(row['Same SKU units Ordered within 1-week of click'])
            infod['Other SKU units Ordered within 1-week of click'] += int(row['Other SKU units Ordered within 1-week of click'])
            infod['Same SKU units Product Sales within 1-week of click'] += float(row['Same SKU units Product Sales within 1-week of click'])
            infod['Other SKU units Product Sales within 1-week of click'] += float(row['Other SKU units Product Sales within 1-week of click'])
        
        # CTR will set -1.0 if not valid
        if infod['Impressions'] != 0:
            infod['CTR'] = infod['Clicks'] / infod['Impressions']
        else:
            infod['CTR'] = -1.0
        # Average CPC and Conversion will set -1.0 if not valid
        if infod['Clicks'] != 0:
            infod['Average CPC'] = infod['Total Spend'] / infod['Clicks']
            infod['Conversion Rate within 1-week of a click'] = infod['Orders placed within 1-week of a click'] / infod['Clicks']
        else:
            infod['Average CPC'] = -1.0
            infod['Conversion Rate within 1-week of a click'] = -1.0
        # ACoS will set -1.0 if not valid
        if infod['Product Sales within 1-week of a click'] != 0:
            infod['ACoS'] = infod['Total Spend'] / infod['Product Sales within 1-week of a click']
        else:
            infod['ACoS'] = -1.0
        
        return infod

    new_column_names = ['Customer Search Term','Keyword','Match Type',
                            'Impressions','Clicks','CTR','Total Spend',
                            'Average CPC','ACoS','Currency','Orders placed within 1-week of a click',
                            'Product Sales within 1-week of a click',
                            'Conversion Rate within 1-week of a click',
                            'Same SKU units Ordered within 1-week of click',
                            'Other SKU units Ordered within 1-week of click',
                            'Same SKU units Product Sales within 1-week of click',
                            'Other SKU units Product Sales within 1-week of click'] 

    # merge single customer search term, return a df (cost 3 minutes)
    def small_merge(sdf, term_name):
        tdf = pd.DataFrame(columns=new_column_names)
        kmps = key_match_pair(sdf)
        for kmp in kmps:
            infod = merge_to_single_row(sdf, kmp, term_name)
            tdf = tdf.append(infod, ignore_index = True)
        return tdf    

    # merge all customer search terms (cost )
    merge_term_df = pd.DataFrame(columns=new_column_names)

    for term in unique_terms:
        sdf = df_no_contain_time[df_no_contain_time['Customer Search Term'] == term]
        tdf = small_merge(sdf, term)
        merge_term_df = merge_term_df.append(tdf, ignore_index = True)

    # display(merge_term_df)
    print("Done\n")
    print("merge_term_df size: ")
    print(merge_term_df.shape)

    print("\nStart outputing final df into xlsx file......(3 minutes) ")
    # import to xlsx
    outputxlsxpath = 'result_SearchTerm.xlsx'
    merge_term_df.to_excel(outputxlsxpath, index=False, header = True)
    # import to csv
    outputcsvpath = 'result.csv'
    merge_term_df.to_csv(outputcsvpath, sep=',', index=False, header = True)
    print("Done\n")



